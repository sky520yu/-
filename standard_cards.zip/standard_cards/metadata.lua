-- SPDX-License-Identifier: GPL-3.0-or-later

return {
  name = "standard_cards",
  author = "official",
  description = "",
  collaborators = {
    program = {},
    designer = {},
    cv = {},
    illustrator = {},
  },

  dependencies = {},
  extra_files = {},
}
