-- SPDX-License-Identifier: GPL-3.0-or-later

-- deprecated file, only for update

-- current hegemony repository is at https://gitee.com/qsgs-fans/hegemony

